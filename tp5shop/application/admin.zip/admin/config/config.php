<?php
/**
 * Created by PhpStorm.
 * User: me
 * Date: 2019/10/14
 * Time: 9:38
 */
return [
    'ACCESSKEY' => 'AL-kEptPtlsd9g9J-qVGoToNXvynyoZQvHuQ3X9A',//你的accessKey
    'SECRETKEY' => 'T-JvJ64LdBHQHQjwHFZmv1kfC_e5fWCk9Dih1dsc',//你的secretKey
    'BUCKET' => 'face123',//上传的空间
    'DOMAIN'=>'http://www.wandu.com/',//空间绑定的域名
    'super_admin'=>['admin'],
    'no_check_power'=>['Index/index']
];