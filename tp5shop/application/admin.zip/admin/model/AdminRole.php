<?php
/**
 * Created by PhpStorm.
 * User: me
 * Date: 2019/10/16
 * Time: 14:51
 */
namespace app\admin\model;
use think\model\Pivot;

class AdminRole extends Pivot{

}