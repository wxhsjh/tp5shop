<?php
/**
 * Created by PhpStorm.
 * User: me
 * Date: 2019/10/12
 * Time: 16:57
 */
namespace app\admin\controller;

use think\Controller;

class Index extends Common{
    public function index(){
        return view();
    }
}